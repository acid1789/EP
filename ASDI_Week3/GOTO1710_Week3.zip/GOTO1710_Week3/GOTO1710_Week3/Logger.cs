﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOTO1710_Week3
{
    class Logger
    {



        override public string ToString()
        {
            return "Hello";
        }
    }
}
